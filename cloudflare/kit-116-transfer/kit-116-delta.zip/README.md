# cloudflare-116

Kit 115 with the Host Game screen's **Level Library...** button 4 px higher, on the line of "Choose Episode:".

- **Worker:** kit 115's (= 114's), byte for byte (`src/`, `wrangler.toml`, the package files, `tools/check-site.mjs`).
- **Page:** kit 115's `index.html`, except its table of engine files.
- **Engines:** OpenJKDF2 branch `claude/project-thread-jbc1no` at `790ee5d` (115's `c6b7889` and this fix).
- `public/` keeps the engine files of kits 93 to 115 (`--keep 21`), and the five fixed-name files from before
  `build-kit.mjs`.

## What's changed

- **Seen on beta in kit 115** (real game, Antonio's game files): the button's top lined up with "Choose Episode:",
  but the button font is taller, so its baseline was 4 game px (8 screen px at 2x) below the label's, in JK and MotS.
  In MotS the "y"'s outline also cut a 6 px notch into the top line of the Episode box.
- **Now:** its rect is 4 higher: `{460,146,170,20}` in JK, `{460,169,170,20}` in MotS. That puts the baselines on one
  line, as in the concept art, and leaves MotS's box line alone. The font and the right edge (630) are kit 115's.
- Both engines' `.js` files are kit 114's, byte for byte; only the two `.wasm` files are new.

## Deploy (beta)

In this folder (the package files are 115's, so its `node_modules` works):

```
npx wrangler deploy --env beta
node tools/check-site.mjs https://beta.jediknight.zone
```

- **The deploy:** the same bindings as 115's beta. It should upload 5 asset files: the page and the two new engine
  `.wasm` files with their `.br`.
- **check-site:** each line `ok`, except the expected `zone` line.

## Deploy (live)

After beta passes and the live lobby has no rooms open:

```
npx wrangler deploy --env=""
node tools/check-site.mjs https://jediknight.zone
```

## Rollback

Live: deploy kit 114 (`jkdf2mp-deploy-cloudflare-114`). Beta: kit 115 or 114.
