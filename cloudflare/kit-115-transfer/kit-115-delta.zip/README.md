# cloudflare-115

Kit 114 with the Host Game screen's **Level Library...** button back in the bigger gold button font.

- **Worker:** kit 114's, byte for byte (`src/`, `wrangler.toml`, the package files, `tools/check-site.mjs`).
- **Page:** kit 114's `index.html`, except its table of engine files.
- **Engines:** OpenJKDF2 branch `claude/project-thread-jbc1no` at `c6b7889` (web-mp `3a55ec5` = kit 114, and this
  change).
- `public/` keeps the engine files of kits 93 to 114 (`--keep 20`), and the five fixed-name files from before
  `build-kit.mjs`.

## What's changed

- **Level Library...** is drawn in the gold button font of Ok, Cancel and Advanced again (med0; med1 with the mouse
  over it; med2 while pressed), as in kit 107, instead of the small font of the labels around it (kits 108 to 114).
  Players reported not seeing the button at all.
- Its rect is kit 107's again: `{460,150,170,20}` in JK, `{460,173,170,20}` in MotS.
- Its text stays right-aligned, ending at 630 (the right edge of the Episode list and the Server Port box), as in
  kit 109: measured in the font it's drawn in, so it doesn't move with the mouse over it.
- Choose Episode's label stays 145 wide, so it doesn't cover the button's left part.
- Nothing else in the engines changed: both `.js` files are kit 114's byte for byte, and in the `.wasm` files the
  only other difference is the build's commit id.

## Deploy (beta)

In this folder (the package files are 114's, so its `node_modules` works):

```
npx wrangler deploy --env beta
node tools/check-site.mjs https://beta.jediknight.zone
```

- **The deploy:** the same bindings as 114's beta. It should upload 5 asset files: the page and the two new engine
  `.wasm` files with their `.br` (both engines' `.js` files are 114's, byte for byte).
- **check-site:** each line `ok`, except the expected `zone` line.

## Deploy (live)

After beta passes and the live lobby has no rooms open:

```
npx wrangler deploy --env=""
node tools/check-site.mjs https://jediknight.zone
```

## Rollback

Deploy kit 114 again (`jkdf2mp-deploy-cloudflare-114`), to beta or live.
